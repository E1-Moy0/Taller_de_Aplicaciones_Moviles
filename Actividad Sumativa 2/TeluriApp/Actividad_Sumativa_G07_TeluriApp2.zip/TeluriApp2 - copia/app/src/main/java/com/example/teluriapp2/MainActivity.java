package com.example.teluriapp2;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import com.example.teluriapp2.models.HttpGetRequest;
import com.example.teluriapp2.models.Sismo;

public class MainActivity extends AppCompatActivity {

    private TextView txtCargando;
    private ListView lvSismos;
    private Button btnActualizar;
    private List<Sismo> elementos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCargando = findViewById(R.id.txtCargando);
        lvSismos = findViewById(R.id.lvSismos);
        btnActualizar = findViewById(R.id.btnActualizar);

        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarDatos();
            }
        });

        cargarDatos();
        iniciarActualizacionPeriodica();
    }

    private void cargarDatos() {
        new HttpGetRequest().execute();
    }

    private void iniciarActualizacionPeriodica() {
        final android.os.Handler handler = new android.os.Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                cargarDatos();
                handler.postDelayed(this, 600000);
            }
        }, 0);
    }

    public class HttpGetRequest extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            String urlAPI = "https://api.gael.cloud/general/public/sismos";

            try {
                // Conexión
                URL url = new URL(urlAPI);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                // Leer la respuesta de API
                InputStream inputStream = conexion.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder resultado = new StringBuilder();
                String linea;
                while ((linea = reader.readLine()) != null) {
                    resultado.append(linea);
                }

                // Cerrar conexiones
                reader.close();
                inputStream.close();
                conexion.disconnect();

                return resultado.toString();

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String resultado) {
            super.onPostExecute(resultado);

            TypeToken<List<Sismo>> typeToken = new TypeToken<List<Sismo>>() {
            };
            elementos = new Gson().fromJson(resultado, typeToken.getType());

            CustomAdapter adaptador = new CustomAdapter(MainActivity.this, elementos);
            lvSismos.setAdapter(adaptador);

            txtCargando.setVisibility(View.INVISIBLE);
            lvSismos.setVisibility(View.VISIBLE);
        }
    }

    class CustomAdapter extends ArrayAdapter<Sismo> {

        private Context mContext;
        private List<Sismo> mSismos;

        public CustomAdapter(Context context, List<Sismo> sismos) {
            super(context, R.layout.fila_lista, sismos);
            mContext = context;
            mSismos = sismos;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(R.layout.fila_lista, parent, false);

            TextView fechaTextView = convertView.findViewById(R.id.fecha_fila_lista);
            TextView descripcionTextView = convertView.findViewById(R.id.RefGeografica_fila_lista);

            Sismo sismo = mSismos.get(position);
            fechaTextView.setText(sismo.Fecha);
            descripcionTextView.setText(sismo.RefGeografica);

            return convertView;
        }
    }
}




//Codigo Original
            /*List<String> lista = new ArrayList<>();
            for (Sismo Sismo : elementos) {
                lista.add(Sismo.Fecha);
            }
            // cargar ListView -> lvArticulos
            ArrayAdapter<String> adaptador = new ArrayAdapter<String>(
                    MainActivity.this,
                    R.layout.fila_lista,
                    R.id.fecha_fila_lista,
                    lista
            );

            lvSismos.setAdapter(adaptador);
            txtCargando.setVisibility(View.INVISIBLE);
            lvSismos.setVisibility(View.VISIBLE);
        }
    }
}*/