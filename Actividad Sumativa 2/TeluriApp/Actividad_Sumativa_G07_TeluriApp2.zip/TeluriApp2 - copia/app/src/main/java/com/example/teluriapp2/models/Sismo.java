package com.example.teluriapp2.models;

public class Sismo {

    public String Fecha;

    public String Profundidad;

    public String Magnitud;

    public String RefGeografica;

    public String FechaUpdate;

}