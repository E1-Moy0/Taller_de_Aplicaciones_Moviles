package com.example.teluriapp2.models;

import android.os.AsyncTask;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
public class HttpGetRequest extends AsyncTask<Void, Void, String> {

    public List<Sismo> elementos;

    @Override
    protected String doInBackground(Void... voids) {
        String urlAPI = "https://api.gael.cloud/general/public/sismos";

        try {
            // Conexión
            URL url = new URL(urlAPI);
            HttpsURLConnection conexion = (HttpsURLConnection) url.openConnection();
            conexion.setRequestMethod("GET");

            // Leer la respuesta de API
            InputStream inputStream = conexion.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder resultado = new StringBuilder();
            String linea;
            while ((linea = reader.readLine()) != null) {
                resultado.append(linea);
            }

            // Cerrar conexiones
            reader.close();
            inputStream.close();
            conexion.disconnect();

            return resultado.toString();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(String resultado)  {
        super.onPostExecute(resultado);

        TypeToken<List<Sismo>> typeToken = new TypeToken<List<Sismo>>() {};
        elementos = new Gson().fromJson(resultado, typeToken.getType());
    }
}
